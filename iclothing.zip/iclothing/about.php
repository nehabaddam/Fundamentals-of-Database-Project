<html>
<head>
	<title>about us</title>
<?php session_start();?>
	<style type="text/css">
			ul {
	  list-style-type: none;
	  margin: 0;
	  padding: 0;
	  overflow: hidden;
	  background-color: #0a0d25;
	}
	li {
	  float: left;
	  border-right:1px solid #bbb;
	}
	li:last-child {
	  border-right: none;
	}
	li a {
	  display: block;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	}

	li a:hover:not(.active) {
	  background-color: #ff844b;
	}

	img { 
		  width: 100%;
		  height: auto;
		}
	#searchimg{
	padding-top: 19px;
	padding-left: 5px;
	height: 20px;
	width: 20px;
	}
	#searchbar{
	padding-bottom: 1px;
	padding-top: 10px;
	border-radius: 22px;
	width: 300px;
	}
	::placeholder{
		color: #0a0d25;
		padding-left: 25px;
	}
		@font-face {
	  font-family: "Kanit";
	  src: url('assets/fonts/Kanit-ExtraLight.ttf') format('truetype');
	}
	body{
		font-family: "Kanit";
		background:#fcf0e4;
	}
		.input[type=text], select, textarea {
  width: 50%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}
.txt{
  margin: 2em;
  left: 50px;
    
  width: 60%; 
  
}
.right {
  position: absolute;
  right: 50px;
  padding: 10px;
}
  </style>
</head>
<body>
	<ul>
  <li><a href="index.html">ICLOTHING</a></li>
  
</ul>
	
    <center><H1>ABOUT US</H1></center>
    <div class="right">
      <img src="assets\images\login\login.jpg">
    </div>
    <div class="txt">
      Clothing industry or garment industry summarizes the types of trade and industry along the production and value chain of clothing and garments, starting with the textile industry (producers of cotton, wool, fur, and synthetic fibre), embellishment using embroidery, via the fashion industry to apparel retailers up to trade with second-hand clothes and textile recycling. The producing sectors build upon a wealth of clothing technology some of which, like the loom, the cotton gin, and the sewing machine heralded industrialization not only of the previous textile manufacturing practices. Clothing industries are also known as allied industries, fashion industries, garment industries, or soft good industries.
      Clothing industry or garment industry summarizes the types of trade and industry along the production and value chain of clothing and garments, starting with the textile industry (producers of cotton, wool, fur, and synthetic fibre), embellishment using embroidery, via the fashion industry to apparel retailers up to trade with second-hand clothes and textile recycling. The producing sectors build upon a wealth of clothing technology some of which, like the loom, the cotton gin, and the sewing machine heralded industrialization not only of the previous textile manufacturing practices. Clothing industries are also known as allied industries, fashion industries, garment industries, or soft good industries.


    </div>
    <br>
    <center><H1>feedback/Query</H1>
      
    <div>
      <div class="container">
  <form method="post">
    <label for="email">email</label>
    <input type="text" id="user_email_form" name="user_email_form" placeholder="Enter Your email id.." required><br>

    <label for="OPTIONS">OPTIONS</label>
    <select name="statement_select" required>

        <option>SELECT OPTIONS</option>
        <option value="feedback">feedback</option>
        <option value="query">query</option>
      </select><br>

    
    <textarea id="feedback" name="feedback" placeholder="Write something.." style="height:200px"></textarea><br>

    <input type="submit" value="Submit" name="submit">
  </form>
</div>       
<?php

error_reporting (E_ALL ^ E_NOTICE);
  $feedback_text = $_POST['feedback'];
  $user_email=$_POST['user_email_form'];
  $statement_type=$_POST['statement_select'];

$conn = mysqli_connect("localhost", "root","", "iclothing");

$query ="insert into feedback(`feedback`,`type`,`user_email`)values('$feedback_text','$statement_type','$user_email')";
$result = mysqli_query($conn, $query);
if($result){
  echo '<script>("THANK YOU FOR YOUR FEEDBACK!");</script>';
  }
?>
</body>
</html>