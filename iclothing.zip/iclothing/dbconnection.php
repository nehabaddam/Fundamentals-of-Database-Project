<html>
<body>
<?php
function makeconnection()
{
	$cn=mysqli_connect("localhost","root","","iclothing");
	if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  return $cn;
}

?>
</body>
</html>