<?php 
session_start();
if(!isset($_SESSION["id"])) {
    header("Location:login.php");
    }

if($_SERVER["REQUEST_METHOD"]=="POST")
{
  if(isset($_POST['Add_To_Cart']))
  {
    if(isset($_SESSION['cart']))
    {
      $myitems=array_column($_SESSION['cart'],'prod_name');
      if(in_array($_POST['prod_name'],$myitems))
      {
        echo"<script>alert('Item Already Added');
          window.location.href='dashboard.php';
        </script>";
      }
      else
      {
        $count=count($_SESSION['cart']);
        $_SESSION['cart'][$count]=array('prod_name'=>$_POST['prod_name'],'prod_cost'=>$_POST['prod_cost'],'Quantity'=>1,'max_quantity'=>$_POST['stock']);
        echo"<script>
          alert('Item Added');
          window.location.href='dashboard.php';
        </script>";
      }
    }
    else
    {
      $_SESSION['cart'][0]=array('prod_name'=>$_POST['prod_name'],'prod_cost'=>$_POST['prod_cost'],'Quantity'=>1,'max_quantity'=>$_POST['stock']);
      echo"<script>
        alert('Item Added');
        window.location.href='dashboard.php';
      </script>";
    }
  }
  if(isset($_POST['Remove_Item']))
  {
    foreach($_SESSION['cart'] as $key => $value)
    {
      if($value['prod_name']==$_POST['prod_name'])
      {
        unset($_SESSION['cart'][$key]);
        $_SESSION['cart']=array_values($_SESSION['cart']);
        echo"<script>
          alert('Item Removed');
          window.location.href='mycart.php';
        </script>";
      }
    }
  }
  if(isset($_POST['Mod_Quantity']))
  {
    foreach($_SESSION['cart'] as $key => $value)
    {
      if($value['prod_name']==$_POST['prod_name'])
      {
        $_SESSION['cart'][$key]['Quantity']=$_POST['Mod_Quantity'];
        echo"<script>
          window.location.href='mycart.php';
        </script>";
      }
    }
  }
}

?>