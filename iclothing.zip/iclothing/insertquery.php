<?php
error_reporting (E_ALL ^ E_NOTICE);
$prodid=$_POST['product_id'];
$userid=$_POST['user_id'];
$user_feedback=$_POST['feedback'];


//echo $prodid,$userid,$user_feedback;

$conn = mysqli_connect("localhost", "root","", "iclothing");
$query ="insert into `product queries`(`prod_id`,`user_id`,`user_query`)values($prodid,$userid,'$user_feedback')";
$query_result = mysqli_query($conn, $query);
if ($query_resulty) {
	echo "<script>
                        alert ('added Successfully!');

                    </script>";
                    header("Location:dashboard.php");
}
?>