<?php
$to       = 'chunduru.sandeep2@gmail.com';
$subject  = 'Testing sendmail';
$message  = 'Hi, you just received an email using sendmail!';
$headers  = 'From: iclothing.fashion@gmail.com' . "\r\n" .
            'MIME-Version: 1.0' . "\r\n" .
            'Content-type: text/html; charset=utf-8';
mail($to, $subject, $message, $headers)
   
?>