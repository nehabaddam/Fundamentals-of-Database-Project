
<!DOCTYPE html>
<html>
<head>
  <?php 
include("header.php"); 
?>
  <?php
        $count=0;
        if(isset($_SESSION['cart']))
        {
          $count=count($_SESSION['cart']);
        }
      ?>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <title>DASHBOARD</title>
  <style type="text/css">
      ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #0a0d25;
  }
  li {
    float: left;
    border-right:1px solid #bbb;
  }
  li:last-child {
    border-right: none;
  }
  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  li a:hover:not(.active) {
    background-color: #ff844b;
  }

 
  #searchimg{
  padding-top: 19px;
  padding-left: 5px;
  height: 20px;
  width: 20px;
  }
  #searchbar{
  padding-bottom: 1px;
  padding-top: 10px;
  border-radius: 22px;
  width: 300px;
  }
  ::placeholder{
    color: #0a0d25;
    padding-left: 25px;
  }
    @font-face {
    font-family: "Kanit";
    src: url('assets/fonts/Kanit-ExtraLight.ttf') format('truetype');
  }
  body{
    font-family: "Kanit";
    background:#fcf0e4;
  }
  .btn
{
  background: #EBECF5;
  color: black;
}

  </style>
</head>
<body>
   <br>
<div class="container" style="max-width: 50%;">
  <input type="text" class="form-control" id="live_search" autocomplete="off" placeholder="search"> 
  </div>
  
      <div id="searchresult">
    
    
  </div>
  <div id="error-message"></div>
  <div id="success-message"></div>
  <script type="text/javascript" src="js/jquery.js"></script>

<script type="text/javascript">
  $(document).ready(function(){
    $("#live_search").keyup(function(){
      var input=$(this).val();
      if(input != ""){
        $.ajax({
          url:"admin/fetch.php",
          method:"POST",
          data:{input:input},
          success:function(data){
            $("#searchresult").html(data);
            $("#searchresult").css("display","block");
          }
        });
      }else{
        $("#searchresult").css("display","none");
      }
e.preventDefault();
    });
  });
</script>
<div class="container py-5">
  <div class="row mt-3">
    <?php
    if(!isset($_SESSION["id"])) {
    header("Location:login.php");
    }
      $cn=mysqli_connect("localhost","root","","iclothing");
      $result=mysqli_query($cn,"select * from products");
      $product_check=mysqli_num_rows($result);
      if ($product_check) 
      {
        while($user_fetch=mysqli_fetch_assoc($result))
        {
          ?>
            
            <div class="col-md-3">
              <br>
              <form action="manage_cart.php" method="post">
                  <div class="card">
                    <div class="card-body">

                      <img src="<?php echo 'admin'."\\".$user_fetch['path'];?>" class="card-img-top" height="300" width="200" alt="product image">
                      <h4 class="card-title"><?php echo "<a href='reviews.php?prodid=$user_fetch[prod_id]'>$user_fetch[prod_name]</a>";?></h2>
                      <h6 ><?php echo "$",$user_fetch['prod_cost'];?></h6>
                      <h6 ><?php
                      $flag=0;
                      if ($user_fetch['stock']<3 AND $user_fetch['stock'] !=0) {
                        echo "Hurry UP ONLY",$user_fetch['stock']," LEFT!!";
                      }
                      if ($user_fetch['stock']==0) {
                        echo "OUT OF STOCK";
                        $flag=1;
                      }

                            ?></h6>
                            <?php 
                            if($flag == 0){

                             echo '<center><button type="submit" name="Add_To_Cart" class="btn btn-primary" >add to cart</button></center>';
                            }
                            ?>
                        
                        <input type="hidden" name="prod_name" value="<?php echo $user_fetch['prod_name'];?>">
                        <input type="hidden" name="prod_cost" value="<?php echo $user_fetch['prod_cost'];?>">
                        <input type="hidden" name="prod_cost" value="<?php echo $user_fetch['prod_cost'];?>">
                        <input type="hidden" name="stock" value="<?php echo $user_fetch['stock'];?>">
                      
                    
                    </div>
                  </div>
                </form>
                </div>
           

          <?php
         
        }
      }
      else
      {
        echo "no products found";
      }

    ?>
       </div>
            </div>



<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>