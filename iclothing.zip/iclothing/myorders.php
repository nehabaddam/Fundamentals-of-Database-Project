<?php
include 'header.php';
           if(!isset($_SESSION["id"])) {
    header("Location:login.php");
    }
    	$userid=$_SESSION["id"];
      $cn=mysqli_connect("localhost","root","","iclothing");
      $result=mysqli_query($cn,"select * from user_orders where user_id='$userid'");
      $product_check=mysqli_num_rows($result);
      if ($product_check) 
      {
        while($user_fetch=mysqli_fetch_assoc($result))
        {
          ?>
            
            <div class="col-md-3">
              <br>
              <form action="manage_cart.php" method="post">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title"><?php echo $user_fetch['Item_Name'];?></h2>
                        <h6 ><?php echo "Quantity: ",$user_fetch['Quantity'];?></h6>
                      <h6 ><?php echo "TOTAL: $",$user_fetch['Price']*$user_fetch['Quantity'];?></h6>
                      <h6 ><?php echo "order placed on ",$user_fetch['date'];?></h6>
                      <h6 ><?php echo "STATUS: ",$user_fetch['status'];?></h6>
                    </div>
                  </div>
                </form>
                </div>
           

          <?php
         
        }
      }
      else
      {
        echo "<center><h1>NO RECENT ORDERS</h1></center>";
      }

?>