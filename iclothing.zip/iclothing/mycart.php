<?php 
include("header.php"); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cart</title>
</head>
<body>
  <div class="container">
    <div class="row">
      

      <div class="col-lg-9">
        <table class="table">
          <thead class="text-center">
            <tr>
              <th scope="col">Serial No.</th>
              <th scope="col">Item Name</th>
              <th scope="col">Item Price</th>
              <th scope="col">Quantity</th>
              <th scope="col">Total</th>              
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody class="text-center">
            <?php 
              if(isset($_SESSION['cart']))
              {
                foreach($_SESSION['cart'] as $key => $value)
                {
                  $sr=$key+1;
                  echo"
                    <tr>
                      <td>$sr</td>
                      <td>$value[prod_name]</td>
                      <td>$value[prod_cost]<input type='hidden' class='iprice' value='$value[prod_cost]'></td>
                      <td>
                        <form action='manage_cart.php' method='POST'>
                          <input class='text-center iquantity' name='Mod_Quantity' onchange='this.form.submit();' type='number' value='$value[Quantity]' min='1' max='$value[max_quantity]' onKeyDown='return false'>
                          <input type='hidden' name='prod_name' value='$value[prod_name]'>
                        </form>
                      </td>
                      <td class='itotal'></td>
                      <td>
                        <form action='manage_cart.php' method='POST'>
                          <button name='Remove_Item' class='btn btn-sm btn-outline-danger'>REMOVE</button>
                          <input type='hidden' name='prod_name' value='$value[prod_name]'>
                        </form>
                      </td>
                    </tr>

                  ";
                }

              }
            ?>

          </tbody>
        </table>

      </div>
      <div class="col-lg-3">
        <div class="border bg-light rounded p-4">
          <h4>Grand Total:</h4><hr>
          <h5 class="text-right" id="gtotal"></h5>
          <br>

    </div>
  </div>

<script>

  var gt=0;
  var iprice=document.getElementsByClassName('iprice');
  var iquantity=document.getElementsByClassName('iquantity');
  var itotal=document.getElementsByClassName('itotal');
  var gtotal=document.getElementById('gtotal');

  function subTotal()
  {
    gt=0;
    for(i=0;i<iprice.length;i++)
    {
      itotal[i].innerText=(iprice[i].value)*(iquantity[i].value);

      gt=gt+(iprice[i].value)*(iquantity[i].value);
    }
    gtotal.innerText="$".concat(gt);
  }
  

  subTotal();

</script>
<div class="border bg-light rounded p-4">
  <form method="POST">
            <div class="form-group">
              <label>Full Name</label>
              <input type="text" name="full_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label>Phone Number</label>
              <input type="number" name="phone_no" class="form-control" required>
            </div>
            <div class="form-group">
              <label>Address</label>
              <input type="text" name="address" class="form-control" required>
            </div>

<div class="card">
            <div class="d-flex justify-content-between px-3 pt-4">
                
                <div class="amount">
                    <div class="inner">

                    </div>
                </div>
            </div>
            <div class="px-3 pt-3">
                <label for="card number" class="d-flex justify-content-between">
                  <input type="radio" name="mode_of_payment" id="cd" value="cod">
                  <label for="cod">CASH ON DELIVERY</label><br>

                  <input type="radio" name="mode_of_payment" id="cc" value="cc">
                  <label for="cc">CREDIT/DEBIT CARD NUMBER</label><br>
                    
                    <img src="mastercard-logo.jpg" width="35%" class="image">
                </label>
                <input type="text" name="cc_number" maxlength="16" class="form-control inputtxt" placeholder="8881 2545 2545 2245" >
            </div>
            <div class="d-flex justify-content-between px-3 pt-4">
                 <div>
                     <label for="date" class="exptxt">Expiry</label>
                     <input type="text" name="cc_expiry" maxlength="4" class="form-control expiry" placeholder="MM / YY">
                 </div>
                 <div>
                    <label for="cvv" class="cvvtxt">CVV /CVC</label>
                    <input type="text" name="cc_cvv"  minlength="3" maxlength="3" class="form-control cvv" placeholder="123">
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-between px-3 py-4">
                <div>
                    <button type="button" class="btn cancel">Cancel</button>
                </div>
                <div>
                    <button class="btn btn-primary btn-block" name="purchase">Make Purchase</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php 
if(!isset($_SESSION["id"])) {
    header("Location:login.php");
    }
$con=mysqli_connect("localhost","root","","iclothing");
if(mysqli_connect_error()){
  echo"<script>
    alert('cannot connect to database');
    window.location.href='mycart.php';
  </script>";
  exit();
}

if($_SERVER["REQUEST_METHOD"]=="POST")
$flag=0;
{
  if(isset($_POST['purchase']))
  {
    $cc_number=$_POST['cc_number'];
  $cc_expiry=$_POST['cc_expiry'];
  $cc_cvv=$_POST['cc_cvv'];
  $payment=$_POST['mode_of_payment'];
  if ($payment=="cod") {
    $flag=0;
  }
  //credit card number validation
  if(!preg_match("/^[0-9]*$/",$_POST['cc_number']))

  {
      echo"<script>alert(' invalid cc number ')</script>";
       $flag++;
       if( strlen((string) $_POST['cc_number'])!=16)
       {
         echo"<script>alert('cc number invalid')</script>";
       $flag=1;
     }
      
  }
  //cvv validation
  if(!preg_match("/^[0-9]*$/",$_POST['cc_cvv']))

  {
      echo"<script>alert(' invalid cvv number ')</script>";
       $flag++;
       if( strlen((string) $_POST['cc_cvv'])!=3)
       {
         echo"<script>alert('cvv number invalid')</script>";
       $flag=1;
     }
      
  }
  

$userid=$_SESSION["id"];

    if($flag==0)
    {
    $query1="INSERT INTO `order_manager`(`user_id`,`Full_Name`, `Phone_No`, `Address`, `Pay_Mode`) VALUES ('$userid','$_POST[full_name]','$_POST[phone_no]','$_POST[address]','$_POST[mode_of_payment]')";
    if(mysqli_query($con,$query1))
    {
      $Order_Id=mysqli_insert_id($con);
      $query2="INSERT INTO `user_orders`(`user_id`,`Order_Id`, `Item_Name`, `Price`, `Quantity`) VALUES ('$userid',?,?,?,?)";
      $stmt=mysqli_prepare($con,$query2);
      if($stmt)
      {
        mysqli_stmt_bind_param($stmt,"isii",$Order_Id,$Item_Name,$Price,$Quantity);
        foreach($_SESSION['cart'] as $key => $values)
        {           
          $Item_Name=$values['prod_name'];
          $Price=$values['prod_cost'];
          $Quantity=$values['Quantity'];
          mysqli_stmt_execute($stmt);
        }
        unset($_SESSION['cart']);
        echo"<script>
          alert('Order Placed');
          window.location.href='dashboard.php';
        </script>";
      }
      else
      {
        echo"<script>
          alert('SQL Query Prepare Error');
          window.location.href='mycart.php';
        </script>";
      }
    }
    else
    {
      echo"<script>
        alert('SQL Error');
        window.location.href='mycart.php';
      </script>";
    }
  }
}
}

?>