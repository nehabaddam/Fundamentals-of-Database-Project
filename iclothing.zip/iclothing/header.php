<?php 
session_start();
if(!isset($_SESSION["id"])) {
    header("Location:login.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <style type="text/css">
      ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #0a0d25;
  }
  li {
    float: left;
    border-right:1px solid #bbb;
  }
  li:last-child {
    border-right: none;
  }
  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  li a:hover:not(.active) {
    background-color: #ff844b;
  }

 
  #searchimg{
  padding-top: 19px;
  padding-left: 5px;
  height: 20px;
  width: 20px;
  }
  #searchbar{
  padding-bottom: 1px;
  padding-top: 10px;
  border-radius: 22px;
  width: 300px;
  }
  ::placeholder{
    color: #0a0d25;
    padding-left: 25px;
  }
    @font-face {
    font-family: "Kanit";
    src: url('assets/fonts/Kanit-ExtraLight.ttf') format('truetype');
  }
  body{
    font-family: "Kanit";
    background:#fcf0e4;
  }
  .btn
{
  background: #EBECF5;
  color: black;
}

  </style>
</head>
<body>
 <ul>
  <li><a href="dashboard.php">ICLOTHING</a></li>
  <li style="float:right"><a href="myorders.php">MY ORDERS</a></li>
  <li style="float:right"><a href="about.php">ABOUT US</a></li>
  <li style="float:right"><a href="logout.php">LOG OUT</a></li>
  
  <?php
        $count=0;
        if(isset($_SESSION['cart']))
        {
          $count=count($_SESSION['cart']);
        }
      ?>
      <li style="float:right;padding-top: 6px"><a href="mycart.php" class="btn btn-success">Cart (<?php echo $count; ?>)</a></li>
  
</ul>
      <div>
    </div>
  </div>
</nav>


</body>
</html>