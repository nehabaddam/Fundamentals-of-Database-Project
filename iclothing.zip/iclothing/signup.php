<html>
<head>
	<?php error_reporting (E_ALL ^ E_NOTICE); ?>
	<?php session_start();  ?>
	<title>Sign up-ICLOTHING</title>

	<style type="text/css">
			ul {
	  list-style-type: none;
	  margin: 0;
	  padding: 0;
	  overflow: hidden;
	  background-color: #0a0d25;
	}
	li {
	  float: left;
	  border-right:1px solid #bbb;
	}
	li:last-child {
	  border-right: none;
	}
	li a {
	  display: block;
	  color: white;
	  text-align: center;
	  padding: 14px 16px;
	  text-decoration: none;
	}

	li a:hover:not(.active) {
	  background-color: #ff844b;
	}

	img { 
		  width: 100%;
		  height: auto;
		}
	#searchimg{
	padding-top: 19px;
	padding-left: 5px;
	height: 20px;
	width: 20px;
	}
	#searchbar{
	padding-bottom: 1px;
	padding-top: 10px;
	border-radius: 22px;
	width: 300px;
	}
	::placeholder{
		color: #0a0d25;
		padding-left: 25px;
	}
		@font-face {
	  font-family: "Kanit";
	  src: url('assets/fonts/Kanit-ExtraLight.ttf') format('truetype');
	}
	body{
		font-family: "Kanit";
		background-color: #fcf0e4;
	}
		.form {
  position: relative;
  z-index: 1;
  background: white;
  max-width: 550px;
  margin: 0 auto 100px;
  padding: 45px;
  margin-top:5em;
  text-align: center;
  box-shadow: 0 0 30px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

.form input {
  font-family: "Kanit";
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}

.form select {
  font-family: "Kanit", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
  COLOR:GREY;
}
.form td{
  font-family: "Kanit", sans-serif;
	font-weight:bold;
}

.form button{
  font-family: "Kanit", sans-serif;
  text-transform :uppercase;
  outline: 0;
width: 100%;
  border: 0;
  padding: 15px;
  background-color: #0a0d25;
  color:#ff844b;
  font-size: 14px;
  cursor: pointer;
   border-radius: 25px;
}

.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}
.form .register-form {
  display: none;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
 clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}

	</style>
</head>
<body>
	<ul>
  <li><a href="index.html">ICLOTHING</a></li>
  <li style="float:right"><a href="about.php">ABOUT US</a></li>
  <li style="float:right"><a href="#cart">CART</a></li>
  <li style="float:right"><a href="login.php">LOGIN</a></li>
</ul>
<?php
if(isset($_SESSION["id"])) {
    echo "<center><h1>YOU ARE ALREADY A MEMBER</h1></center>";
    }
else
{

echo '
	<center>
		<div class="reg_page">
  		<div class="form">
    	<form method="post">
    		<table>
    			<tr>
    				<td id="name">Name</td>
    				<td><input type="text" name="name" size="50" placeholder="enter your name" required></td>
    			</tr>
    			<tr>
					<td id="td">E-mail</td>
					<td><input type="text" name="email" placeholder="enter your email" pattern="/[a-z]+\@[a-z]+\.[com|co\.in|co\.us|co\.jp]" required></td>
				</tr>
				<tr>
				<td id="td">Contact number</td>
				<td><input type="text" name="phone" placeholder="enter your mobile number" required></td>
			</tr>
				<tr>
					<td id="td">Password</td>
					<td><input type="password" name="password" placeholder="enter your password" required></td>
				</tr>
				<tr>
					<td id="td">Confirm Password</td>
					<td><input type="password" name="cnfpassword"placeholder="enter your password again" required></td>
				</tr>
				<tr>
				<td></td><td><button name="insert">REGISTER
			</tr>
    		
    		</table>

    	</form>
		</div>
		</div>
	</center>';
}
?>

</body>
</html>
<?php


$cn=mysqli_connect("localhost","root","","iclothing");
$name=$_POST['name'];
$email=$_POST['email'];
$phn=$_POST['phone'];
$password=$_POST['password'];
$cnf_password=$_POST['cnfpassword'];

if (isset($_POST['insert']))
  
{
  if ($password!==$cnf_password) {
    echo "<script>
                        alert ('passwords doesnot match');
                    </script>";
  }
  else{


  $existing_result = mysqli_query($cn,"SELECT * FROM users WHERE email='" . $_POST["email"] . "'");
  $existing_user_row  = mysqli_fetch_array($existing_result);

  if(is_array($existing_user_row)) {
  echo "<script>
                  alert ('user already exist!');
              </script>";
  
  }
  else
  {


  $insert_query="INSERT INTO `users`(`name`, `email`, `phn`, `password`) VALUES ('$name','$email','$phn','$password')";
  try
  {
    $insert_result=mysqli_query($cn, $insert_query);
    if($insert_result)
    {
      if(mysqli_affected_rows($cn)>0)
      {
         echo "<script>
                        alert ('Registered Successfully!');
                    </script>";
        
      }
      else
      { echo "<script>
                        alert ('error in Registering!');
                    </script>";
      }
    }
  }
  catch(Exception $ex)
  {
    echo("error inserted".$ex->getMessage());
  }
}
}
}
?>