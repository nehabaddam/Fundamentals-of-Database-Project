<?php
include 'header.php';
           if(!isset($_SESSION["id"])) {
    header("Location:login.php");
    }
      $prodid=$_GET['prodid'];
      $userid=$_SESSION["id"];
      $cn=mysqli_connect("localhost","root","","iclothing");
      $result=mysqli_query($cn,"select * from products where prod_id='$prodid'");
      $product_check=mysqli_num_rows($result);
      if ($product_check) 
      {
        while($user_fetch=mysqli_fetch_assoc($result))
        {
          ?>

            <div class="container">
            <div class="row">
              <div class="col-md-3">
              <br>

              <form method="post" action="insertquery.php">
                  <div class="card">
                    <div class="card-body">

                      <img src="<?php echo 'admin'."\\".$user_fetch['path'];?>" class="card-img-top" height="300" width="200" alt="product image">
                      
                        <h6 ><?php echo "Product name: ",$user_fetch['prod_name'];?></h6>
                      <h6 ><?php echo "cost: $",$user_fetch['prod_cost'];?></h6>
                      <div class="col-md-3">
                <br><center><textarea id="feedback" name="feedback" placeholder="Any Queries?" style="height:100px;width: 200px"></textarea><br>
                  
                 <input type="hidden" name="product_id" value="<?php echo $user_fetch['prod_id']; ?>">
                 <input type="hidden" name="user_id" value="<?php echo $_SESSION["id"];?>">
                
                <input type="submit" name="submit" value="ask"></center>

              </div>
                    </div>
                  </div>
                </form>
                </div>
                <div class="col-md-9">
                <?php
$query_display=mysqli_query($cn,"select * from `product queries` where prod_id='$prodid'");
                  while($print_qna=mysqli_fetch_assoc($query_display))
                  {
                    if (is_null($print_qna['admin_reply'])) {
                      echo "<br>*",$print_qna['user_query'];
                    }
                    else {
                      echo "<br>*",$print_qna['user_query'];
                      echo "<br>->",$print_qna['admin_reply'];
                    }
                    
                  }
?>
              </div>
            </div>
            


              

          <?php
          
         
        }
      }
      else
      {
        echo "<center><h1>NO RECENT ORDERS</h1></center>";
      }

?>