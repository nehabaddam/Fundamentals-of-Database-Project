<?php
    session_start();
    $message="";
    if(count($_POST)>0) {
        $con = mysqli_connect("localhost","root","","iclothing");
        $result = mysqli_query($con,"SELECT * FROM admin WHERE admin_email='" . $_POST["email"] . "' and admin_password = '". $_POST["password"]."'");
        
        $row  = mysqli_fetch_array($result);

        if(is_array($row)) {
        $_SESSION["admin_id"] = $row['admin_id'];
        $_SESSION["admin_name"] = $row['admin_name'];
        } else {
         $message = "Invalid Username or Password!";
        }
    }
    if(isset($_SESSION["admin_id"])) {
    header("Location:admin_dashboard.php");
    }
?>
<html>
<head>
	<title>ADMIN LOGIN</title>
  <style type="text/css">
      ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #0a0d25;
  }
  li {
    float: left;
    border-right:1px solid #bbb;
  }
  li:last-child {
    border-right: none;
  }
  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  li a:hover:not(.active) {
    background-color: #ff844b;
  }

  img { 
      width: 100%;
      height: auto;
    }
  #searchimg{
  padding-top: 19px;
  padding-left: 5px;
  height: 20px;
  width: 20px;
  }
  #searchbar{
  padding-bottom: 1px;
  padding-top: 10px;
  border-radius: 22px;
  width: 300px;
  }
  ::placeholder{
    color: #0a0d25;
    padding-left: 25px;
  }
    @font-face {
    font-family: "Kanit";
    src: url('assets/fonts/Kanit-ExtraLight.ttf') format('truetype');
  }
  body{
    font-family: "Kanit";
    background:#fcf0e4;
  }
    .form {
  position: relative;
  z-index: 1;
  background: white;
  max-width: 550px;
  margin: 0 auto 100px;
  padding: 45px;
  margin-top:5em;
  text-align: center;
  box-shadow: 0 0 30px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

.form input {
  font-family: "Kanit";
  outline: 0;
  background: #f2f2f2;
  width: 150%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}

.form select {
  font-family: "Kanit", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
  COLOR:GREY;
}
.form td{
  font-family: "Kanit", sans-serif;
  font-weight:bold;
}

.form button{
  font-family: "Kanit", sans-serif;
  text-transform :uppercase;
  outline: 0;
width: 100%;
  border: 0;
  padding: 15px;
  background-color: #0a0d25;
  color:#ff844b;
  font-size: 14px;
  cursor: pointer;
   border-radius: 25px;
}

.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}
.form .register-form {
  display: none;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
 clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}
  </style>

</head>
<body>
	
	<center>
   <h1>ADMIN</h1>
		<div class="reg_page">
  		<div class="form">
    	<form method="post">
    		<table>
    			
    			<tr>
					<td id="td">E-mail or Phone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><input type="text" name="email"  placeholder="enter your email OR Phone Number" pattern="/[a-z]+\@[a-z]+\.[com|co\.in|co\.us|co\.jp]" required></td>
				</tr>
				
				<tr>
					<td id="td">Password&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><input type="password" name="password"  placeholder="enter your password" required></td>
				</tr>
				
				<tr>
				<td></td><td><button  name="login" value="login">LOG-IN</BUTTON></td>
			</tr>
    			<tr>
    				<td></td>
    			</tr>
    		</table>

    	</form>
    	
		</div>

		</div>

	</center>

</body>
</html>