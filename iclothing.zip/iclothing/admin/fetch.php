<?php
session_start();
if(!isset($_SESSION["admin_id"])) {
    header("Location:admin_login.php");
    }
    if (isset($_POST['input'])) {
    	$input=$_POST['input'];
      $cn=mysqli_connect("localhost","root","","iclothing");
      $result=mysqli_query($cn,"SELECT * FROM products WHERE prod_name LIKE '%{$input}%' OR category LIKE '%{$input}%' OR subcategory LIKE '%{$input}%' LIMIT 3");
      $product_check=mysqli_num_rows($result);
      if ($product_check) 
      {
        while($user_fetch=mysqli_fetch_assoc($result))
        {
          ?>
            <div class="col-md-4">
              <br>
              <form action="manage_cart.php" method="post">
                  <div class="card">
                    <div class="card-body">

                      <img src="<?php echo 'admin'."\\".$user_fetch['path'];?>" class="card-img-top" height="300" width="200" alt="product image">
                      <h4 class="card-title"><?php echo $user_fetch['prod_name'];?></h2>
                      <h6 ><?php echo "$",$user_fetch['prod_cost'];?></h6>
                      <h6 ><?php
                      $flag=0;
                      if ($user_fetch['stock']<3 AND $user_fetch['stock'] !=0) {
                        echo "Hurry UP ONLY",$user_fetch['stock']," LEFT!!";
                      }
                      if ($user_fetch['stock']==0) {
                        echo "OUT OF STOCK";
                        $flag=1;
                      }

                            ?></h6>
                            <?php 
                            if($flag == 0){

                             echo '<center><button type="submit" name="Add_To_Cart" class="btn btn-primary" >add to cart</button></center>';
                            }
                            ?>
                        
                        <input type="hidden" name="prod_name" value="<?php echo $user_fetch['prod_name'];?>">
                        <input type="hidden" name="prod_cost" value="<?php echo $user_fetch['prod_cost'];?>">
                        <input type="hidden" name="prod_cost" value="<?php echo $user_fetch['prod_cost'];?>">
                      
                    </div>
                    </div>
                  </div>
                </form>
                </div>
           

          <?php
         
        }
      }
      else
      {
        echo "no products found";
      }
}
    ?>