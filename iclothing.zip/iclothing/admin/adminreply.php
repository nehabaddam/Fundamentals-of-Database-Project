<?php
session_start();
if(!isset($_SESSION["admin_id"])) {
    header("Location:admin_login.php");
    }

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>



<div class="container">
  <form method="POST">
   

   

    <label for="REPLY">REPLY</label>
    <textarea id="REPLY" name="REPLY" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" value="SEND MAIL" name="submit">
    <a href="feedbacks.php">back to feedbacks</a>
  </form>
</div>

</body>
</html>
<?php
error_reporting (E_ALL ^ E_NOTICE);
if (isset($_POST['submit'])) {
	$conn = mysqli_connect("localhost", "root","", "iclothing");
  $reply=$_POST['REPLY'];
  $tblid=$_GET['prodid'];

$query ="UPDATE `product queries` SET `admin_reply`='$reply' WHERE `query_table_id`='$tblid'";
$query_result = mysqli_query($conn, $query);
if ($query_resulty) {
  echo "<script>
                        alert ('replied Successfully!');

                    </script>";
                 
}
		?>