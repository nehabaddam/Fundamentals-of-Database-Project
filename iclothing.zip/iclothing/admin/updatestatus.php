<?php
session_start();
error_reporting (E_ALL ^ E_NOTICE);
?>
<html>
<head>
	<title>UPDATE STATUS-ICLOTHING</title>
  <style type="text/css">
      ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #0a0d25;
  }
  li {
    float: left;
    border-right:1px solid #bbb;
  }
  li:last-child {
    border-right: none;
  }
  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
  }

  li a:hover:not(.active) {
    background-color: #ff844b;
  }

  img { 
      width: 100%;
      height: auto;
    }
  #searchimg{
  padding-top: 19px;
  padding-left: 5px;
  height: 20px;
  width: 20px;
  }
  #searchbar{
  padding-bottom: 1px;
  padding-top: 10px;
  border-radius: 22px;
  width: 300px;
  }
  ::placeholder{
    color: #0a0d25;
    padding-left: 25px;
  }
    @font-face {
    font-family: "Kanit";
    src: url('assets/fonts/Kanit-ExtraLight.ttf') format('truetype');
  }
  body{
    font-family: "Kanit";
    background:#fcf0e4;
  }
    .form {
  position: relative;
  z-index: 1;
  background: white;
  max-width: 550px;
  margin: 0 auto 100px;
  padding: 45px;
  margin-top:5em;
  text-align: center;
  box-shadow: 0 0 30px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

.form input {
  font-family: "Kanit";
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
}

.form select {
  font-family: "Kanit", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 14px;
  COLOR:GREY;
}
.form td{
  font-family: "Kanit", sans-serif;
  font-weight:bold;
}

.form button{
  font-family: "Kanit", sans-serif;
  text-transform :uppercase;
  outline: 0;
width: 100%;
  border: 0;
  padding: 15px;
  background-color: #0a0d25;
  color:#ff844b;
  font-size: 14px;
  cursor: pointer;
   border-radius: 25px;
}

.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
}
.form .message a {
  color: #4CAF50;
  text-decoration: none;
}
.form .register-form {
  display: none;
}
.container {
  position: relative;
  z-index: 1;
  max-width: 300px;
  margin: 0 auto;
}
.container:before, .container:after {
  content: "";
  display: block;
 clear: both;
}
.container .info {
  margin: 50px auto;
  text-align: center;
}
.container .info h1 {
  margin: 0 0 15px;
  padding: 0;
  font-size: 36px;
  font-weight: 300;
  color: #1a1a1a;
}
.container .info span {
  color: #4d4d4d;
  font-size: 12px;
}
.container .info span a {
  color: #000000;
  text-decoration: none;
}
.container .info span .fa {
  color: #EF3B3A;
}
  </style>

</head>
<body>
	<ul>
  <li><a href="admin_dashboard.php">ICLOTHING ORDERS</a></li>
  <li style="float:right"><a href="admin_dashboard.php">ORDERS</a></li>
  <li style="float:right"><a href="admin_logout.php">LOGOUT</a></li>
</ul>

	<center>
   
		<div class="reg_page">
  		<div class="form">
    	<form action='' method='POST' enctype='multipart/form-data'>
    		<table>
    			<tr>
         <td id="td">UPDATE ORDER STATUS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
         <td><select name="upadte_status" id="category">
  <option value="AWAITING CONFIRMATION">AWAITING CONFIRMATION</option>
  <option value="CONFIRMED">CONFIRMED</option>
  <option value="IN TRANSIT">IN TRANSIT</option>
  <option value="DELIVERED">DELIVERED</option>
  <option value="DELAYED">DELAYED</option>
  <td><input type='submit' name='upadtestatus'>
</select></td>

    		</table>
    	</form>
		</div>
		</div>
	</center>
</body>
</html>
<?php

if(!isset($_SESSION["admin_id"])) {
    header("Location:admin_login.php");
    }
$cn=mysqli_connect("localhost","root","","iclothing");

if (isset($_POST['upadtestatus']))
{

  
  $status=$_POST['upadte_status'];
  $productname=$_GET['prodname'];
  $quantity=$_GET['prodquantity'];
  $orderid=$_GET['orderid'];
  $userpageid=$_GET['id'];


  if($status=="DELIVERED")
  {

    $update_stockquery="UPDATE products SET stock = (stock - $quantity) WHERE `prod_name`='$productname'";
    $update_stockresult=mysqli_query($cn,$update_stockquery);
    $update_query="UPDATE `user_orders` SET `status`='$status' WHERE user_id='$userpageid' AND `Item_Name`='$productname' AND `Order_Id`='$orderid'";
    try
    {
      $update_result=mysqli_query($cn, $update_query);
      if($update_result)
      {
        if(mysqli_affected_rows($cn)>0)
        {
           echo "<script>
                          alert ('status updated Successfully!');
                      </script>";
          
        }
        else
        { echo "<script>alert ('error in updatig status!');</script>";
        }
      }
    }
    catch(Exception $ex)
    {
      echo("error inserted".$ex->getMessage());
    }
  }
  if ($status=="CONFIRMED") {
    
    $fetch_email_query="SELECT * from `users` where `id`=1 ";
    $fetch_email_result=mysqli_query($cn,$fetch_email_query);
    while($fetch_email=mysqli_fetch_assoc($fetch_email_result))
    {     
      $user_email=$fetch_email['email'];
         $to       = $user_email;
        $subject  = 'ORDER CONFIRMATION';
        $message  = 'Hi, your order is confirmed!!';
        $headers  = 'From: iclothing.fashion@gmail.com' . "\r\n" .
                    'MIME-Version: 1.0' . "\r\n" .
                    'Content-type: text/html; charset=utf-8';
        mail($to, $subject, $message, $headers);
    }
    $update_query="UPDATE `user_orders` SET `status`='$status' WHERE user_id='$userpageid' AND `Item_Name`='$productname' AND `Order_Id`='$orderid'";
  try
  {
    $update_result=mysqli_query($cn, $update_query);
    if($update_result)
    {
      if(mysqli_affected_rows($cn)>0)
      {
         echo "<script>
                        alert ('status updated Successfully!');
                    </script>";
        
      }
      else
      { echo "<script>alert ('error in updatig status!');</script>";
      }
    }
  }
  catch(Exception $ex)
  {
    echo("error inserted".$ex->getMessage());
  }
  }

else{

  $update_query="UPDATE `user_orders` SET `status`='$status' WHERE user_id='$userpageid' AND `Item_Name`='$productname' AND `Order_Id`='$orderid'";
  try
  {
    $update_result=mysqli_query($cn, $update_query);
    if($update_result)
    {
      if(mysqli_affected_rows($cn)>0)
      {
         echo "<script>
                        alert ('status updated Successfully!');
                    </script>";
        
      }
      else
      { echo "<script>alert ('error in updatig status!');</script>";
      }
    }
  }
  catch(Exception $ex)
  {
    echo("error inserted".$ex->getMessage());
  }
}
}

?>